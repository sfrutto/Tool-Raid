names = ["Fucked By " ]
message = """
# @everyone FUCKED BY 

##  on top

https://discord.gg/

"""
token = "TOKEN_BOT"